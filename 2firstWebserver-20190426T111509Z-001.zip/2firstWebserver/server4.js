var http = require('http');
var fs = require('fs');

//page not found 404
function notFound(res){
	  res.writeHead(200,{"Content-type":"text/html"});
	  res.write("<h2 style='color:red'>Error 404 , page not found!!!</h2>");
	  res.end();
}

function reqHandler(req, res){
	if(req.method=='GET' && req.url=='/'){
		console.log("request received at 8080");
		 res.writeHead(200,{"Content-type":"text/html"});
		 //fs.createReadStream("./index.html").pipe(res);
		 //_______________________________________________________________________________
		 // var filename = __dirname+req.url;
		 var filename = "./index.html";

  // This line opens the file as a readable stream
  var readStream = fs.createReadStream(filename);

  // This will wait until we know the readable stream is actually valid before piping
  readStream.on('open', function () {
      // This just pipes the read stream to the response object (which goes to the client)
	console.log("reading stream..!!");
    readStream.pipe(res);
  });
  
  readStream.on('end', function() {
     console.log('end of readStream'+filename);
});

  // This catches any errors that happen while creating the readable stream (usually invalid names)
  readStream.on('error', function(err) {
    res.write(err);
  });
  
		 //_________________________________________________________________________________________
		 //res.write("Welcome to index");
  res.end();
  console.log("response sent..!!!");
	}
	else{
		notFound(res);
	}
	
}
var server = http.createServer(reqHandler);
server.listen(8080);
console.log("Server started at 8080");