var http = require('http');
var fileSystem = require('fs');
//page not found 404
function notFound(response){
	  response.writeHead(200,{"Content-type":"text/html"});
	  response.write("<h2 style='color:red'>Error 404 , page not found!!!</h2>");
	  response.end();
}
function reqHandler(request, response){
if(request.method=='GET' && request.url=='/'){
    response.writeHead(200, {
        'Content-Type': 'text/html',
    });
fileSystem.createReadStream('./index.html').pipe(response);
 }
else{
	notFound(response);
}
}
http.createServer(reqHandler ).listen(8888);
console.log("Server started at 8888");