var http = require('http');
var fileSystem = require('fs');

http.createServer(function(request, response) {

    response.writeHead(200, {
        'Content-Type': 'text/html',
    });

    var readStream = fileSystem
					.createReadStream('./index.html');
    readStream.pipe(response);
})
.listen(2000);