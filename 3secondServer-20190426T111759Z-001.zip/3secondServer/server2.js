var http= require('http');
var connect=require('connect');
var app= connect();
function welcome(req,res,n){
	console.log("welcome is called..!!");
	 res.writeHead(200,{"Content-type":"text/html"});
	  res.write("<h2 style='color:blue'>You requested welcome page</h2>");
	  res.end();
	//n();
}
function profile(req,res,n){
	console.log("profile is called..!!");
	 res.writeHead(200,{"Content-type":"text/html"});
	  res.write("<h2 style='color:green'>You requested profile page</h2>");
	  res.end();
	//n();
}

app.use('/profile',profile);
app.use('/',welcome);
http.createServer(app).listen(8888);
console.log("Server is running..!!")