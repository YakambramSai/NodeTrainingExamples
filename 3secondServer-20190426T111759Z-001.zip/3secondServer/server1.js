var http= require('http');
var connect=require('connect');
var app= connect();
function welcome(req,res,n){
	console.log("welcome is called..!!");
	n();
}
function profile(req,res,n){
	console.log("profile is called..!!");
	n();
}

app.use('/profile',profile);
app.use('/',welcome);
http.createServer(app).listen(8888);
console.log("Server is running..!!")