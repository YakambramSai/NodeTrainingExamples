var http= require('http');
var connect=require('connect');
var app= connect();
function first(req,res,n){
	console.log("first is called..!!");
	n();
}
function second(req,res,n){
	console.log("second is called..!!");
	n();
}
app.use(first);
app.use(second);
http.createServer(app).listen(8888);
console.log("Server is running..!!")