//not in node6
var path =  require("path");
path.exists('/etc/passwd', function (exists) {
 var data = exists ? "it's there" : "no passwd!";
  console.log(data);
});