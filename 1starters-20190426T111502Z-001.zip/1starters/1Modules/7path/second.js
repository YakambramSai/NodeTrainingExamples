var path = require("path");

console.log(path.join('/foo', 'bar', 'baz/asdf', 'quux', '..'));
// returns '/foo/bar/baz/asdf'
 

console.log(path.resolve('foo/bar', '/tmp/file/', '..', 'a/../subfile'));
//path.dirname(p) , 
//path.basename('/foo/bar/baz/asdf/quux.html', '.html')
//path.extname('index.html')