var path = require("path");


// path
console.log('path : ' + path.normalize('/foo/bar//baz/asdf/quux/..'));

