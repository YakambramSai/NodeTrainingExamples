var readline = require('readline');
var net = require('net');
var server = net.createServer(function(socket) {
	console.log('client connected!');
	//socket.write('Echo server\r\n');
	var rl = readline.createInterface(process.stdin, process.stdout);
	rl.setPrompt('>>> ');
	rl.prompt();
	rl.on('line', function(line) {
		socket.write(line);
		if (line === "exit") rl.close();
		rl.setPrompt('>>> ');
		rl.prompt();
	}).on('close',function(){
		process.exit(0);
	});
	//.........................
	//socket.pipe(socket);
	socket.on('end', function() {
		console.log('client disconnected');
   });
   socket.on('data', function (data) {
        console.log('client: '+data.toString());
		
    });
});

server.listen(1337, '192.168.2.10');
server.on('error',function(){})




