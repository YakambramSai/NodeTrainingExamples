var net = require('net');
var readline = require('readline');
var client = new net.Socket();
client.connect(1337, '192.168.2.10', function() {
	console.log('Connected');
	//..............................................
	var rl = readline.createInterface(process.stdin, process.stdout);
	rl.setPrompt('>>> ');
	rl.prompt();
	rl.on('line', function(line) {
		client.write(line);
		if (line === "exit") rl.close();
		rl.setPrompt('>>> ');
		
	}).on('close',function(){
		process.exit(0);
	});
});

client.on('data', function(data) {
	console.log('Server: ' + data);
	//client.destroy(); // kill client after server's response
});

client.on('close', function() {
	console.log('Connection closed');
});
