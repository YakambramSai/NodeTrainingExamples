var os = require("os");
var data = os.networkInterfaces();
console.log(data);
//	os.hostname() ,os.networkInterfaces() ,os.EOL