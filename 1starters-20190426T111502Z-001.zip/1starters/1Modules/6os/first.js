var os = require('os');
console.log("Platform: " + os.platform());
console.log("Architecture: " + os.arch());
