var events = require('events');
var eventEmitter = new events.EventEmitter();


//Assign the eventhandler to an event:
eventEmitter.on('myevent', ()=> {
				  console.log('Our custom event was emitted!');
				});

//Fire the  event:
eventEmitter.emit('myevent');
