var fs = require('fs');

fs.rename('mynewfile1.txt', 'myrenamedfile.txt', function (err) {
	try{
			if (err) throw err;
	}
	catch(err){
		console.log('Some error occurred!');
		console.log(err);
	}
  
  console.log('File Renamed!');
});