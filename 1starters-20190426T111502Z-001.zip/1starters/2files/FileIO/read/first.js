var fs = require('fs');

 fs.readFile('first.js', (err, data)=> {
  
    console.log(data.toString());
    
  });