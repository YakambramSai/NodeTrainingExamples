var fs = require('fs');

//create an empty file named mynewfile2.txt:
fs.open('mynewfile2.txt', 'w', function (err, file) {
  if (err) throw err;
  fs.write(file,'Hello World!');
  console.log('Saved!');
});
