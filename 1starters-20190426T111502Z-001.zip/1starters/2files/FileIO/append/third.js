var fs = require('fs');

fs.readdir('.',function(err,items){
	console.log(items);
});
