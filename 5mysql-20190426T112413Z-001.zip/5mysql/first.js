var mysql = require('mysql');
var pool =  mysql.createPool({
host : 'localhost',
user : 'root',
password: '',
database: 'test'
});
 
var createTable = "CREATE TABLE employee(id int(11) NOT NULL AUTO_INCREMENT,"+
    "name varchar(20) DEFAULT NULL,"+
    "salary float(11) DEFAULT NULL,"+
    "PRIMARY KEY (id)) ENGINE=InnoDB DEFAULT CHARSET=latin1";
 
pool.getConnection(function(err, connection){    
  //Create a table called employee
  connection.query(createTable,  function(err){
    if(err) throw err;
    else {
        console.log('Table created!');
    }
  });
 
  connection.release();//release the connection
});