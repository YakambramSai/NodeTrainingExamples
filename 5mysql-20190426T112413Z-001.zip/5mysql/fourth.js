var mysql = require('mysql');
var pool =  mysql.createPool({
host : 'localhost',
user : 'root',
password: '',
database: 'test'
});
var updateRecord = 'UPDATE employee SET salary = ? WHERE name=?';
pool.getConnection(function(err, connection){    
//Update a record.
 connection.query(updateRecord,[60000,'Joe'], function(err, res){
    if(err) throw err;
    else {
        console.log('Increased the salary for Joe.');
    }
  });
 
  connection.release();//release the connection
});