var mysql = require('mysql');
var pool =  mysql.createPool({
	host : 'localhost',
	user : 'root',
	password: '',
	database: 'test'
});

var readTable = 'SELECT * FROM employee';

pool.getConnection(function(err, connection){    


 
  //Read table.
  connection.query(readTable, function(err, rows){
    if(err) throw err;
    else {
        console.log(rows);
    }
  });
 
  connection.release();//release the connection
});