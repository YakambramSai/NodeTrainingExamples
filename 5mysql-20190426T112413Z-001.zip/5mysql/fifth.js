var mysql = require('mysql');
var pool =  mysql.createPool({
host : 'localhost',
user : 'root',
password: '',
database: 'test'
});



 
var deleteRecord = 'DELETE FROM employee WHERE name=?';
 
   /*
var dropTable = 'DROP table employee';
 */
pool.getConnection(function(err, connection){    


 
  
  //Delete a record.
  connection.query(deleteRecord,['Joe'], function(err, res){
    if(err) throw err;
    else {
        console.log('An employee is removed.');
    }
  });
 /*
  //Drop a table.
  connection.query(dropTable, function(err, res){
    if(err) throw err;
    else {
        console.log('The employee table is removed.');
    }
  });
 */
  connection.release();//release the connection
});