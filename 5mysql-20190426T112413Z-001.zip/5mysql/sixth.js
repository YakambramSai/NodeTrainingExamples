var mysql = require('mysql');
var pool =  mysql.createPool({
host : 'localhost',
user : 'root',
password: '',
database: 'test'
});

var dropTable = 'DROP table employee';

pool.getConnection(function(err, connection){    

  //Drop a table.
  connection.query(dropTable, function(err, res){
    if(err) throw err;
    else {
        console.log('The employee table is removed.');
    }
  });
  connection.release();//release the connection
});